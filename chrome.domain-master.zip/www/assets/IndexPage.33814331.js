import { _ as _export_sfc } from "./plugin-vue_export-helper.21dcd24c.js";
import { D as defineComponent } from "./index.c74185c9.js";
const _sfc_main = defineComponent({
  name: "IndexPage"
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return " '' ";
}
var IndexPage = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { IndexPage as default };
