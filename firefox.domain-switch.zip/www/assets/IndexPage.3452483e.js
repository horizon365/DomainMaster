import { _ as _export_sfc, D as defineComponent } from "./index.5b4ae035.js";
const _sfc_main = defineComponent({
  name: "IndexPage"
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return " '' ";
}
var IndexPage = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { IndexPage as default };
