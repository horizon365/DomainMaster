import { u as useQuasar, Q as QSeparator, a as QChip } from "./use-quasar.9fbf02c6.js";
import { Q as QList, a as QItem, b as QItemSection } from "./portal.870fd005.js";
import { r as ref, E as shallowRef, a as computed, j as openBlock, k as createElementBlock, l as createVNode, m as withCtx, F as createBlock, G as createCommentVNode, I as Fragment, J as renderList, L as createTextVNode, M as QIcon, N as createBaseVNode, O as withDirectives, R as withModifiers, S as toDisplayString, U as QAvatar } from "./index.5b4ae035.js";
import { C as ClosePopup } from "./ClosePopup.357495fd.js";
import "./use-dark.3f1dfbf7.js";
var PopUp_vue_vue_type_style_index_0_lang = "";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("a", {
  href: "/www/index.html#/options",
  target: "_blank"
}, "Change Settings", -1);
const _sfc_main = {
  __name: "PopUp",
  setup(__props) {
    const $q = useQuasar();
    const currentUrl = ref("");
    const currentPare = ref("");
    const envs = shallowRef([]);
    const energies = shallowRef([]);
    if ($q.platform.is.bex) {
      $q.bex.send("storage.get", { key: "envs" }).then((res) => {
        if (!res.data || !res.data.length) {
          return;
        }
        console.log("options: get value from storage", res.data);
        envs.value = JSON.parse(res.data);
      });
      $q.bex.send("storage.get", { key: "energies" }).then((res) => {
        if (!res.data || !res.data.length) {
          return;
        }
        console.log("options: get value from storage", res.data);
        energies.value = JSON.parse(res.data);
      });
      $q.bex.send("get.url", {}).then((res) => {
        if (!res.data) {
          return;
        }
        currentUrl.value = res.data.baseUrl;
        currentPare.value = res.data.pareterms;
        console.log("get current url: ", res.data);
      });
    }
    function getSearchQueryFromUrl(matchedUrl) {
      const regex = /\?([^&]*)=/;
      const match = matchedUrl.match(regex);
      const key = match[1];
      const queryParams = new URLSearchParams(currentPare.value);
      console.log("currentPare", currentPare.value);
      console.log("queryParams", queryParams);
      console.log("key", key);
      return queryParams.get(key);
    }
    const searchPar = computed(() => {
      console.log("currentUrl", currentUrl);
      let matchedUrl;
      for (const url of energyUrls.value) {
        if (url.includes(currentUrl.value)) {
          matchedUrl = url;
        }
      }
      console.log("matchedUrl", matchedUrl);
      return getSearchQueryFromUrl(matchedUrl);
    });
    const envUrls = computed(() => {
      const urlLists = [];
      for (const project of envs.value) {
        for (const row of project.rows) {
          urlLists.push(row.url);
        }
      }
      return urlLists;
    });
    const energyUrls = computed(() => {
      const urlLists = [];
      for (const project of energies.value) {
        for (const row of project.rows) {
          urlLists.push(row.url);
        }
      }
      return urlLists;
    });
    function getItems(key) {
      let projects;
      if (key === "envs") {
        projects = envs.value;
      } else {
        projects = energies.value;
      }
      for (const project of projects) {
        for (const row of project.rows) {
          if (row.url.includes(currentUrl.value)) {
            return project.rows;
          }
        }
      }
    }
    function removeHttp(url) {
      return url.replace(/^(http:\/\/|https:\/\/)/, "");
    }
    function switchDomain(type, current_url, target_url, openInNewTab) {
      console.log("\u63A5\u53D7\u5230switchDomain\u8BF7\u6C42", current_url, target_url);
      $q.bex.send("switch.domain", {
        type,
        current_url,
        target_url,
        openInNewTab
      });
      currentUrl.value = removeHttp(target_url);
    }
    function checkURLs(project) {
      const rows = project.rows;
      rows.forEach((row) => {
        const url = row.protocol + row.url;
        console.log("begin try: ", url);
        fetch(url).then((response) => {
          console.log(`${url}: ${response.status}`);
          if (response.status === 200) {
            switchDomain("subscribe_url", currentUrl.value, url, true);
          }
        }).catch((error) => {
          console.error(`Error fetching ${url}:`, error);
        });
      });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QList, null, {
          default: withCtx(() => [
            envUrls.value.includes(currentUrl.value) ? (openBlock(), createElementBlock("div", _hoisted_1, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(getItems("envs"), (item) => {
                return withDirectives((openBlock(), createBlock(QItem, {
                  clickable: "",
                  key: item.id
                }, {
                  default: withCtx(() => [
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createVNode(QChip, {
                          clickable: "",
                          color: currentUrl.value.includes(item.url) ? "primary" : void 0,
                          onClick: ($event) => switchDomain("envs", currentUrl.value, item.protocol + item.url, false),
                          onContextmenu: withModifiers(($event) => switchDomain("envs", currentUrl.value, item.protocol + item.url, true), ["right"])
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(item.name), 1)
                          ]),
                          _: 2
                        }, 1032, ["color", "onClick", "onContextmenu"])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)), [
                  [ClosePopup]
                ]);
              }), 128))
            ])) : (openBlock(), createBlock(QItem, { key: 1 }, {
              default: withCtx(() => [
                createVNode(QItemSection, { class: "tip" }, {
                  default: withCtx(() => [
                    createTextVNode("Not a registered domain")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }))
          ]),
          _: 1
        }),
        createVNode(QSeparator),
        createVNode(QList, { style: { "min-width": "100px" } }, {
          default: withCtx(() => [
            energyUrls.value.some((url) => url.includes(currentUrl.value)) ? (openBlock(), createElementBlock("div", _hoisted_2, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(getItems("energy"), (item) => {
                return withDirectives((openBlock(), createBlock(QItem, {
                  clickable: "",
                  key: item.id
                }, {
                  default: withCtx(() => [
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createVNode(QChip, {
                          clickable: "",
                          color: item.url.includes(currentUrl.value) ? "primary" : void 0,
                          onClick: ($event) => switchDomain("energy", currentUrl.value + currentPare.value, item.protocol + item.url + searchPar.value, false),
                          onContextmenu: withModifiers(($event) => switchDomain("energy", currentUrl.value + currentPare.value, item.protocol + item.url + searchPar.value, true), ["right"])
                        }, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(item.name), 1)
                          ]),
                          _: 2
                        }, 1032, ["color", "onClick", "onContextmenu"])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)), [
                  [ClosePopup]
                ]);
              }), 128))
            ])) : (openBlock(), createBlock(QItem, { key: 1 }, {
              default: withCtx(() => [
                createVNode(QItemSection, { class: "tip" }, {
                  default: withCtx(() => [
                    createTextVNode("Not a registered engine")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }))
          ]),
          _: 1
        }),
        createVNode(QSeparator),
        envs.value && envs.value.length > 0 ? (openBlock(), createBlock(QList, { key: 0 }, {
          default: withCtx(() => [
            (openBlock(true), createElementBlock(Fragment, null, renderList(envs.value, (project) => {
              return openBlock(), createBlock(QItem, {
                key: project.name
              }, {
                default: withCtx(() => [
                  createVNode(QItemSection, { avatar: "" }, {
                    default: withCtx(() => [
                      createVNode(QChip, {
                        "icon-right": "directions",
                        clickable: "",
                        onClick: ($event) => checkURLs(project),
                        color: "primary",
                        "text-color": "white"
                      }, {
                        default: withCtx(() => [
                          createVNode(QAvatar, {
                            color: "red",
                            "text-color": "white"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(project.rows.length), 1)
                            ]),
                            _: 2
                          }, 1024),
                          createTextVNode(" Ping " + toDisplayString(project.name) + " Environment ", 1)
                        ]),
                        _: 2
                      }, 1032, ["onClick"])
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 2
              }, 1024);
            }), 128))
          ]),
          _: 1
        })) : createCommentVNode("", true),
        envs.value && envs.value.length > 0 ? (openBlock(), createBlock(QSeparator, { key: 1 })) : createCommentVNode("", true),
        createVNode(QItem, {
          clickable: "",
          "active-class": "my-menu-link"
        }, {
          default: withCtx(() => [
            createVNode(QItemSection, { avatar: "" }, {
              default: withCtx(() => [
                createVNode(QIcon, { name: "settings" })
              ]),
              _: 1
            }),
            createVNode(QItemSection, null, {
              default: withCtx(() => [
                _hoisted_3
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 64);
    };
  }
};
export { _sfc_main as default };
